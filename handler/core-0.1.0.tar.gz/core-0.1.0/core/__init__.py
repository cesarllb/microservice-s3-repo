from .enviroment_variables import bootstrap

bootstrap()